from django.apps import AppConfig

class EventsConfig(AppConfig):
    name = 'applications.events'
    label = "events"
