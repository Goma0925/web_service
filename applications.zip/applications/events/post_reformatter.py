# def reformat_time(time_str):
#     new_time_str = ""
#     if time_str[-2:-1] == "am"
#         is_AM = True
#
#     if is_AM:
#         new_time_str = time_str.rstrip(" am")
#     else:
#         new_time_str = time_str.rstrip(" am")
