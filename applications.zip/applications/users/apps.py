from django.apps import AppConfig


class CustomUsersConfig(AppConfig):
    name = 'applications.users'
    label = "users"
